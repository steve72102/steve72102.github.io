'use strict';
// Isolated art contract probe: eight front RUN cells, never registered by game startup.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const direction=process.argv[2]||'down';
if(!['down','left','right','up'].includes(direction))throw Error('Direction must be down/left/right/up');
const pilot=path.resolve(__dirname,'../..');
const game=path.resolve(pilot,'../../..','game');
const sourceId=`doctor-${direction}-v1`,id=`doctor-crossline-common-${direction}-run-v1`;
const source=path.join(game,'assets','painted-avatar',sourceId,'manifest.json');
const outDir=path.join(pilot,'outfit-artwork-front-pilot','multitier-doctor-v1','runtime-pilot',id);
const artDir=path.join(pilot,'outfit-artwork-front-pilot','multitier-doctor-v1',`${direction}-run-jacket-candidates`);
const oldJacket='fruit-pineapple-jacket',newJacket='style-fusion-academy-crossline-common-jacket';
const m=JSON.parse(fs.readFileSync(source));
if(m.id!==sourceId||m.coverage.cells.length<15||m.passes.length<20)throw Error('Source contract changed');
delete m.extensionOf;
m.id=id;
m.label=`交線學院 COMMON 博士 ${direction} RUN8｜隔離分件試作`;
m.revision=`crossline-common-${direction}-run8-20261116`;
m.coverage.cells=m.coverage.cells.filter(c=>c.direction===direction&&c.sheet==='run');
m.items.jacket=[newJacket];
for(const entry of m.loadoutCoverage.entries)if(entry.jacket===oldJacket)entry.jacket=newJacket;
fs.mkdirSync(outDir,{recursive:true});
for(const pass of m.passes){
  if(pass.ownerSlot==='jacket'&&pass.itemId===oldJacket)pass.itemId=newJacket;
  pass.frames=pass.frames.filter(f=>f.direction===direction&&f.sheet==='run');
  if(pass.frames.length!==8)throw Error('Incomplete pass '+pass.id);
  for(const frame of pass.frames){
    for(const [field,prefix] of [['image',''],['compactImage','compact-']]){
      const name=pass.id==='jacket'?`${prefix}${direction}-run-${frame.frame}-jacket.png`:path.basename(frame[field]);
      const input=pass.id==='jacket'?path.join(artDir,name):path.join(game,'assets','painted-avatar',sourceId,name);
      const output=path.join(outDir,name);
      if(!fs.existsSync(input))throw Error('Missing art '+input);
      fs.copyFileSync(input,output);
      frame[field]=`./assets/painted-avatar/${m.id}/${name}`;
    }
  }
}
m.provenance={stage:'isolated-direction-run8-candidate',parentManifest:`game/assets/painted-avatar/${sourceId}/manifest.json`,parentManifestSha256:crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),newJacketSource:`outfit-artwork-front-pilot/multitier-doctor-v1/${direction}-run-jacket-candidates`,sourceArtMethod:'generated run sheet, original per-cell jacket alpha mask, pixel-exact source-layer composite',verifiedDirections:[],verifiedActions:[],deployed:false};
fs.writeFileSync(path.join(outDir,'manifest.json'),JSON.stringify(m,null,2)+'\n');
console.log(JSON.stringify({id:m.id,cells:m.coverage.cells.length,passes:m.passes.length,loadouts:m.loadoutCoverage.entries.length,stage:m.provenance.stage}));
