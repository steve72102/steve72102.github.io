# 交線學院 COMMON／博士外套：四方向 RUN8 隔離增量

## 本批範圍

- 保留 `game/assets/painted-avatar/doctor-{down,left,right,up}-v1/` 原圖及原 manifest，未覆寫。
- 以四個原生方向各八張 RUN 格為定位，重新繪製深綠、金邊學院外套；這是同一件外套的四方向候選，不使用鏡像補方向。
- 用原 jacket 分件的逐像素 alpha 遮罩取出新衣；原臉髮、手、褲子、鞋子與其他裝備層仍從原遊戲各格取用。
- 每方向八張 `256×384` 透明 jacket，另有 `96×144` compact 版；四份隔離 manifest 沿用八欄 ID 格式和 256 項 loadout allowlist，僅把 jacket ID 換成 `style-fusion-academy-crossline-common-jacket`。
- 原來源合成圖：`doctor-{direction}-run-original-composite-padded.png`。候選遮罩合成：`doctor-{direction}-run-jacket-masked-qa.png`。源生成圖：`source-generated/doctor-{direction}-run-edit.png`。

## 已檢查

- 四方向八格共 32 格，原角色臉髮、手、褲子、鞋子的像素來源由既有分件重合成；新衣只進 jacket 層。
- 目視檢查四張八格合成圖；側面與背面保持方向及原本動作節奏，沒有用另一方向鏡像。
- 現有 `painted-avatar.js` 的 `validateManifest` 接受四份 manifest：`down 8/20`、`left 8/21`、`right 8/21`、`up 8/20`（格數／pass 數）。這是格式與引用約束測試，不等於真實遊戲通過。

## 尚未通過

- 四份 manifest 是獨立隔離試作，**尚未整合為一個不替換原底稿的 runtime 裝備系列**。現有 renderer 的 base manifest 一角色僅一份，直接登記會替換現有博士底稿；不能直接發到 `/game/`。
- idle／actions、其餘七欄交線學院新服裝、衣櫥、商城、背包、場景、購買／升級與真實 UI 都未完成或未驗收。
- 這批只覆蓋博士 COMMON 外套的 RUN8；不是十人五級的完成品。原有黃外套的非 jacket 輔助 pass 可能在特殊混搭露出，須在整合時逐 loadout 檢查。
- 畫質屬可目視審核的候選；需要真實遊戲像素對位及逐格穿脫驗收後才能標記成品。

## 重建

在隔離 worktree 執行：

```powershell
foreach($d in @('down','left','right','up')) {
  & .\outfit-artwork-front-pilot\multitier-doctor-v1\build-down-run-source.ps1 -Direction $d
  & .\outfit-artwork-front-pilot\multitier-doctor-v1\extract-down-run-jackets.ps1 -Direction $d
  node .\tools\outfit-recipe\build-crossline-doctor-down-run.cjs $d
}
```

已生成的來源圖放在 `source-generated/`，重建不需連線或付費 API。此階段只做素材切分，不會更動玩家金幣、存檔、Firebase 規則或正式網站。
