'use strict';
const fs = require('node:fs');
const path = require('node:path');
const file = path.resolve(__dirname, '../../game/assets/painted-avatar/professor-crossline-common-v1/manifest.json');
let text = fs.readFileSync(file, 'utf8');
const prefix = 'style-fusion-academy-crossline-';
for (const slot of ['cape', 'shirt', 'pants', 'shoes', 'accessory', 'handheld']) {
  text = text.replaceAll(prefix + 'common-' + slot, prefix + 'professor-common-' + slot);
}
const manifest = JSON.parse(text);
const jacket = prefix + 'professor-common-jacket';
if (manifest.items.jacket.includes(jacket)) throw Error('Professor manifest already prepared');
manifest.items.jacket.push(jacket);
manifest.outfitOf.newItemIds.push(jacket);
for (const [source, id, itemId] of [
  ['crossline-jacket', 'professor-jacket', jacket],
]) {
  const part = manifest.passes.find(pass => pass.id === source);
  if (!part) throw Error('Missing source pass: ' + source);
  const images=JSON.parse(JSON.stringify(part.images));
  for(const direction of Object.keys(images))for(const sheet of Object.keys(images[direction])){
    images[direction][sheet]=images[direction][sheet].replace(/jacket-candidate-v[12]\.png$/,'jacket-clean-v1.png');
  }
  manifest.passes.push({...part, id, itemId, images});
}
manifest.label = '交線學院 COMMON 教授七欄原畫候選（帽子待繪）';
fs.writeFileSync(file, JSON.stringify(manifest, null, 2) + '\n');
console.log('Prepared professor COMMON manifest with seven new item IDs.');
