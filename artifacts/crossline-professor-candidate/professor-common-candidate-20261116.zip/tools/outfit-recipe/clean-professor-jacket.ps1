Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies 'System.Drawing.dll' -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class ProfessorJacketClean {
  public static void Run(string source, string destination) {
    using (var input = new Bitmap(source))
    using (var output = new Bitmap(input.Width, input.Height, PixelFormat.Format32bppArgb)) {
      using (var canvas = Graphics.FromImage(output)) canvas.DrawImageUnscaled(input, 0, 0);
      var rect = new Rectangle(0, 0, output.Width, output.Height);
      var bits = output.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
      try {
        int size = Math.Abs(bits.Stride) * bits.Height;
        var data = new byte[size];
        Marshal.Copy(bits.Scan0, data, 0, size);
        for (int y = 0; y < bits.Height; y++) for (int x = 0; x < bits.Width; x++) {
          int i = y * bits.Stride + x * 4;
          int b = data[i], g = data[i + 1], r = data[i + 2];
          // The source sheet's warm gray backdrop leaked into the jacket mask.
          // Keep dark painted cloth and saturated gold edging; strip neutral light pixels.
          if (r >= 105 && g >= 100 && b >= 90 && r - g < 31 && g - b < 31 && r - b < 53) {
            data[i + 3] = 0;
          }
        }
        Marshal.Copy(data, 0, bits.Scan0, size);
      } finally { output.UnlockBits(bits); }
      output.Save(destination, ImageFormat.Png);
    }
  }
}
'@
$root = Resolve-Path (Join-Path $PSScriptRoot '../../game/assets/painted-avatar/professor-crossline-common-v1')
foreach ($direction in @('down','up','left','right')) {
  foreach ($sheet in @('actions','run')) {
    $version = if ($direction -eq 'up') { 'v2' } else { 'v1' }
    $source = Join-Path $root "professor-$direction-$sheet-jacket-candidate-$version.png"
    $target = Join-Path $root "professor-$direction-$sheet-jacket-clean-v1.png"
    [ProfessorJacketClean]::Run($source, $target)
  }
}
