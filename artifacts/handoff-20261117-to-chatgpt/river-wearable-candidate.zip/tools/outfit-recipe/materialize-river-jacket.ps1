param(
  [string]$Source = 'game/assets/painted-avatar/professor-crossline-common-v1',
  [string]$Destination = 'game/assets/painted-avatar/professor-river-coat-v1'
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies @('System.Drawing.Common','System.Drawing.Primitives','System.Private.Windows.GdiPlus','System.Private.Windows.Core') -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class RiverMaterial {
  public static void Render(string source, string destination) {
    using (var input = new Bitmap(source)) {
      if (input.Width != 1024 || input.Height != 768) throw new Exception("Atlas must be 1024x768");
      using (var bitmap = new Bitmap(input.Width,input.Height,PixelFormat.Format32bppArgb)) {
        using (var g = Graphics.FromImage(bitmap)) g.DrawImage(input,0,0,input.Width,input.Height);
        var rect = new Rectangle(0,0,bitmap.Width,bitmap.Height);
        var bits = bitmap.LockBits(rect,ImageLockMode.ReadWrite,PixelFormat.Format32bppArgb);
        try {
          var bytes = new byte[Math.Abs(bits.Stride)*bits.Height];
          Marshal.Copy(bits.Scan0,bytes,0,bytes.Length);
          for (int y=0;y<bitmap.Height;y++) for(int x=0;x<bitmap.Width;x++) {
            int i=y*bits.Stride+x*4;
            int b=bytes[i],gr=bytes[i+1],r=bytes[i+2],a=bytes[i+3];
            if(a<20) continue;
            // Keep skin, white collar and hand details from the accepted source.
            bool gold=r>105 && r>gr*1.17 && gr>b*1.1 && gr>50;
            bool cloth=r<145 && gr<145 && b<145 && !(r>gr*1.45 && r>95);
            if(gold){
              int l=(r+gr+b)/3;
              bytes[i]=(byte)Math.Min(255,l+35);
              bytes[i+1]=(byte)Math.Min(255,l+26);
              bytes[i+2]=(byte)Math.Min(255,l+18);
            }else if(cloth){
              int l=(r*3+gr*6+b)/10;
              bytes[i]=(byte)Math.Min(255,Math.Max(14,l*1.32+18));
              bytes[i+1]=(byte)Math.Min(255,Math.Max(12,l*1.02+9));
              bytes[i+2]=(byte)Math.Min(255,Math.Max(10,l*.78+4));
              // Add an original fine waterline embroidery to the existing moving hem.
              int cellX=x%256,cellY=y%384;
              if(cellY>190 && cellY<247 && cellX>61 && cellX<192){
                double wave=212+5*Math.Sin((cellX-67)*.075)+3*Math.Sin((cellX-67)*.14);
                if(Math.Abs(cellY-wave)<.7 && l>25){bytes[i]=196;bytes[i+1]=180;bytes[i+2]=157;}
              }
            }
          }
          Marshal.Copy(bytes,0,bits.Scan0,bytes.Length);
        } finally { bitmap.UnlockBits(bits); }
        bitmap.Save(destination,ImageFormat.Png);
      }
    }
  }
}
'@
$sourcePath=(Resolve-Path -LiteralPath $Source).Path
$destinationPath=[IO.Path]::GetFullPath((Join-Path (Get-Location) $Destination))
[IO.Directory]::CreateDirectory($destinationPath) | Out-Null
foreach($direction in @('down','left','right','up')){
  foreach($sheet in @('actions','run')){
    $name="professor-$direction-$sheet-jacket-clean-v1.png"
    $inputPath=Join-Path $sourcePath $name
    if(-not [IO.File]::Exists($inputPath)){throw "Missing source atlas: $name"}
    $outputPath=Join-Path $destinationPath "professor-$direction-$sheet-river-jacket-v1.png"
    [RiverMaterial]::Render($inputPath,$outputPath)
    Write-Output $outputPath
  }
}
