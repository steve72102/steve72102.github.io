'use strict';
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const source=path.join(root,'game/assets/painted-avatar/professor-crossline-common-v1/manifest.json');
const outDir=path.join(root,'game/assets/painted-avatar/professor-river-coat-v1');
const old=JSON.parse(fs.readFileSync(source,'utf8'));
const m=structuredClone(old);
m.id='professor-river-coat-v1';
m.revision='river-material-v1-20261117';
m.label='溪藍研習衣教授四方向 RUN8 材質試作';
m.items.jacket.push('wish-river-coat');
m.outfitOf={...m.outfitOf,family:'river-study-professor',newItemIds:['wish-river-coat']};
m.borrowedSources=['professor-v1','professor-crossline-common-v1'];
m.provenance={stage:'material-derived-motion-atlas',artAcceptance:'unreviewed',source:'professor-crossline-common-v1 jacket alpha and motion; wish-river-coat-v1 product concept',note:'Original character body, face, hair and hands retained. New river-blue fabric and fine waterline embroidery use the same fitted moving jacket cut; silhouette review pending.'};
const images={};
for(const direction of ['down','left','right','up']){
  images[direction]={};
  for(const sheet of ['actions','run']){
    const rel=`./assets/painted-avatar/${m.id}/professor-${direction}-${sheet}-river-jacket-v1.png`;
    if(!fs.existsSync(path.join(root,'game',rel)))throw Error(`Missing ${rel}`);
    images[direction][sheet]=rel;
  }
}
m.passes.push({id:'river-jacket',ownerSlot:'jacket',itemId:'wish-river-coat',z:50,images});
fs.mkdirSync(outDir,{recursive:true});
fs.writeFileSync(path.join(outDir,'manifest.json'),JSON.stringify(m,null,2)+'\n');
console.log(path.join(outDir,'manifest.json'));
