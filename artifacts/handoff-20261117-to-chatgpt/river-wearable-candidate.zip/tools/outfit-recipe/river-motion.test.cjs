'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const P=require('../../game/painted-avatar.js');

test('river jacket keeps its own ID and moving professor layer in four directions',()=>{
  const root=path.resolve(__dirname,'../..');
  const baseRoot=path.resolve(root,'../../..');
  const read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
  const base=read(path.join(baseRoot,'game/assets/painted-avatar/professor-v1/manifest.json'));
  const crossline=read(path.join(root,'game/assets/painted-avatar/professor-crossline-common-v1/manifest.json'));
  const river=read(path.join(root,'game/assets/painted-avatar/professor-river-coat-v1/manifest.json'));
  const runtime=P.createRuntime();
  runtime.registerManifest({...base,outfitOnly:true});
  runtime.registerOutfitManifest(crossline);
  runtime.registerOutfitManifest(river);
  const state={appearance:{character:'professor'},rpg:{loadout:{jacket:'wish-river-coat',shirt:'style-fusion-academy-crossline-professor-common-shirt'}}};
  assert.equal(runtime.supports(state),true);
  for(const direction of P.DIRECTIONS)for(const sheet of P.SHEETS){
    const plan=runtime.plan(state,direction,sheet,{frame:0});
    assert.equal(plan.id,'professor-river-coat-v1');
    assert.equal(plan.loadout.jacket,'wish-river-coat');
    assert.ok(plan.passes.some(pass=>pass.itemId==='wish-river-coat'&&pass.url.includes(`${direction}-${sheet}-river-jacket-v1.png`)));
    assert.equal(plan.passes.some(pass=>pass.itemId==='style-fusion-academy-crossline-professor-common-jacket'),false);
  }
});
